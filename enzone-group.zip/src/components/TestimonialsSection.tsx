import React from 'react';

const TESTIMONIALS = [
  {
    quote: "ENZONE GROUP delivers on schedule and product quality has been consistent since our very first batch. That reliability in both product potency and credit transparency is what keeps us reordering every single month.",
    name: "Ashraf K.",
    role: "Regional Distribution Partner, Malappuram"
  },
  {
    quote: "I joined as an intern with no prior manufacturing experience. Through structured shop-floor training, I learned compounding and batch QA. Today I oversee a full production line — ENZONE truly invests in local talent.",
    name: "Fathima N.",
    role: "Production & Compounding Specialist, Kozhikode"
  },
  {
    quote: "Their herbal formulations and household cleaning ranges move off the shelves quickly once shoppers try them. Consistent wholesale margins and prompt factory replenishment make stocking ENZONE effortless.",
    name: "Rajeev M.",
    role: "Supermarket & Retail Stockist, Kozhikode"
  },
  {
    quote: "For bulk institutional hygiene and hospital-grade surface disinfectants, finding a Kerala manufacturer with verifiable batch certificates and reliable 48-hour emergency dispatch was critical. ENZONE has delivered without exception.",
    name: "Naveen Kurian",
    role: "Commercial Procurement Lead, Ernakulam"
  },
  {
    quote: "Clear distributor pricing tiers and protected territory allotments give us the confidence to build deep retail coverage across North Kerala without channel conflict or unexpected price fluctuations.",
    name: "Suresh Baburaj",
    role: "Wholesale Trade Merchant, Kannur"
  },
  {
    quote: "Handling container consignments from Cochin port requires meticulous export compliance, phytosanitary clearance, and robust palletization. ENZONE met every international specification seamlessly.",
    name: "Tariq Al-Mansoor",
    role: "Commercial Export Partner, GCC Region"
  }
];

export const TestimonialsSection: React.FC = () => {
  return (
    <section className="py-[80px] sm:py-[120px] lg:py-[140px] bg-[#EDE8DE] border-t border-[#1a1a14]/10" id="testimonials">
      <div className="content-wrap">
        {/* Intro */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-20 mb-[40px] sm:mb-[70px]">
          <div className="lg:col-span-4">
            <span className="font-mono-spec text-[11px] sm:text-xs text-[#6d7266] uppercase tracking-widest block">
              Partner & Network Voices
            </span>
          </div>
          <div className="lg:col-span-8">
            <h2 className="font-display text-[clamp(28px,5.2vw,68px)] leading-[1.08] sm:leading-[1] tracking-tight sm:tracking-[-2px] lg:tracking-[-3px] font-semibold text-[#1c2624]">
              What partners and customers say.
            </h2>
          </div>
        </div>

        {/* 6-Item Editorial Grid with Precise Dividers */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 border-t border-b border-[#1a1a14]/15">
          {TESTIMONIALS.map((item, idx) => {
            const isLeftMd = idx % 2 === 0;
            const isLeftLg = idx % 3 === 0;
            const isMidLg = idx % 3 === 1;
            const isRightLg = idx % 3 === 2;

            const isLastMobile = idx === TESTIMONIALS.length - 1;
            const isLastRowMd = idx >= 4;
            const isLastRowLg = idx >= 3;

            return (
              <div
                key={idx}
                className={`py-8 sm:py-10 flex flex-col justify-between gap-6 border-b border-[#1a1a14]/15 ${
                  // Horizontal padding
                  isLeftMd ? 'md:pr-8 md:pl-0' : 'md:pl-8 md:pr-0'
                } ${
                  isLeftLg ? 'lg:pl-0 lg:pr-8' : isMidLg ? 'lg:px-8' : 'lg:pl-8 lg:pr-0'
                } ${
                  // Vertical borders
                  isLeftMd ? 'md:border-r md:border-[#1a1a14]/15' : 'md:border-r-0'
                } ${
                  !isRightLg ? 'lg:border-r lg:border-[#1a1a14]/15' : 'lg:border-r-0'
                } ${
                  // Bottom borders on last rows
                  isLastMobile ? 'border-b-0' : ''
                } ${
                  isLastRowMd ? 'md:border-b-0' : 'md:border-b'
                } ${
                  isLastRowLg ? 'lg:border-b-0' : 'lg:border-b'
                }`}
              >
                <div>
                  <div className="font-display text-[32px] sm:text-[38px] leading-none text-[#b54e23] font-semibold mb-3 sm:mb-4">
                    “
                  </div>
                  <p className="text-[14.5px] sm:text-[15.5px] leading-[1.7] sm:leading-[1.72] text-[#1a1a14] font-sans-body">
                    {item.quote}
                  </p>
                </div>

                <div className="pt-4 border-t border-[#1a1a14]/15">
                  <div className="font-display font-semibold text-[15px] text-[#1c2624]">
                    {item.name}
                  </div>
                  <div className="text-xs sm:text-[13px] text-[#6d7266] mt-0.5">
                    {item.role}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
